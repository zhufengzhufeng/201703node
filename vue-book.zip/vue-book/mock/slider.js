module.exports = [
  '//image4.suning.cn/uimg/cms/img/149788424640147846.jpg',
  '//image2.suning.cn/uimg/cms/img/149787421566598471.jpg',
  '//image2.suning.cn/uimg/cms/img/149787428742824667.jpg'
];
